#include<stdio.h>
#include<conio.h>
int a[10][10],n;
void bfs(int);
void main()
{
    int i,j,src;
    printf("enter the no of nodes:");
    scanf("%d",&n);
    printf("enter the adjacency matrix:");
    for(i=1;i<=n;i++){
        for(j=1;j<=n;j++)
        {
          scanf("%d",&a[i][j]);   
        }
    }
    printf("enter the source node:");
    scanf("%d",&src);
     bfs(src);
}
void bfs(int src){
    int q[10],r=0,f=-1,vis[10],i,j;
    for(j=1;j<=n;j++){
        vis[j]=0;
    }
    vis[src]=1;
    r=r+1;
    q[r]=src;
    while(f<=r){
        i=q[f];
        f=f+1;
        for(j=1;j<=n;j++){
            if(a[i][j]==1 && vis[j]!=1){
                vis[j]=1;
                r=r+1;
                q[r]=j;
            }
        }
    }
    for(j=1;j<=n;j++){
        if(vis[j]!=1){
            printf("node %d is not reachable.",j);
        }
        else{
            printf("node %d is reachable.",j);
        }
    }


}